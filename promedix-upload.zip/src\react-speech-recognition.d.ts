declare module 'react-speech-recognition' {
  const SpeechRecognition: any;
  export default SpeechRecognition;
  export const useSpeechRecognition: any;
}
